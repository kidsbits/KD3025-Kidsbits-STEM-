'''
LPS331AP 1.0
'''

from machine import Pin
from machine import I2C
#import numpy as np
import time
import math
# import ustruct


LPS331AP_I2C_ADDR = 0x5D            
WHO_AM_I_REG = 0x0F

REF_P_XL = 0x08        #压力参考值
REF_P_LR = 0x09
REF_P_HR = 0x0A
RES_CONF = 0x10        #压力分辨率
CTRL_REG1 = 0x20        #数据控制寄存器
CTRL_REG2 = 0x21        #内存控制寄存器

CTRL_REG3 = 0x22        #中断控制寄存器
INTERRUPT_CFG = 0x23        #中断配置
INT_SOURCE = 0x24        #中断源
THS_P_L = 0x25        #中断压力阈值（LSB）
THS_P_HT = 0x26
STATUS_REG = 0x27        #状态寄存器

PRESS_OUT_XLP = 0x28        #压力数据[7:0]
PRESS_OUT_LP = 0x29        #压力数据[15:8]
PRESS_OUT_H = 0x2A        #压力数据[23:16]

TEMP_OUT_L = 0x2B        #温度数据
TEMP_OUT_H = 0x2C
AMP_CTELA = 0x2D        #模拟运算放大器数据采集电流控制

DELTA_PRESS_XL = 0x3C        #压力偏差[7:0]
DELTA_PRESS_L1 = 0x3D        #压力偏差[15:8]
DELTA_PRESS_L2 = 0x3E        #压力偏差[23:16]
CHIP_ID = 0xBB


class lps331ap:
    def __init__(self, bus, scl, sda):
        self.bus = bus
        self.scl = scl
        self.sda = sda
        self.temp_data = 0
        self.pressure_data = 0

        time.sleep(1)
        self.i2c = I2C(self.bus, scl = self.scl, sda = self.sda, freq = 100000)
        slv = self.i2c.scan()
        #print(slv)
        for s in slv:
            buf = self.i2c.readfrom_mem(s, WHO_AM_I_REG, 1)
            #print(buf)
            if(buf[0] == CHIP_ID):
                self.slvAddr = s
                print('lps331ap found')
                #print(self.slvAddr)
                break
        time.sleep(1)

    def writeByte(self, addr, data):
        d = bytearray([data])
        self.i2c.writeto_mem(self.slvAddr, addr, d)
        
    def readByte(self, addr):
        return self.i2c.readfrom_mem(self.slvAddr, addr, 1)

    def measure(self):
        self.writeByte(RES_CONF,0x7A)  # 设置采样分辨率
        self.writeByte(CTRL_REG1,0x80) # 启动 
        self.writeByte(CTRL_REG2,0x01) # 0x01 设置为单次采集模
        buf = self.readByte(STATUS_REG)
        if (buf[0] & 0x03) == 0x03:
            buf1 = self.readByte(PRESS_OUT_XLP)
            buf2 = self.readByte(PRESS_OUT_LP)
            buf3 = self.readByte(PRESS_OUT_H)
            buf4 = self.readByte(TEMP_OUT_L)
            buf5 = self.readByte(TEMP_OUT_H)
            P_RAW = buf1[0] + buf2[0]*256 +buf3[0]*256*256 #(int32_t)((buf3 << 16) | (buf2 << 8 | buf1); # 24bit
            T_RAW = buf4[0] + buf5[0]*256 #(int16_t)((buf5 << 8) | (buf4)) & 0xffff; # 16bit
            
            sign_bit = T_RAW & 0x8000  # 0x8000 是16位补码的符号位掩码
        
            # 如果是正数，直接返回
            if sign_bit == 0:
                decimal_value = T_RAW
            else:    
                # 如果是负数，进行补码到原始值的转换
                inverted_bits = T_RAW ^ 0xFFFF  # 0xFFFF 是16位补码的按位取反掩码
                decimal_value = -(inverted_bits + 1)

            self.temp_data = decimal_value / 480 + 42.5            

            sign_bit = P_RAW & 0x800000  # 0x800000 是24位补码的符号位掩码
        
            # 如果是正数，直接返回
            if sign_bit == 0:
                decimal_value = P_RAW
            else:    
                # 如果是负数，进行补码到原始值的转换
                inverted_bits = P_RAW ^ 0xFFFFFF  # 0xFFFFFF 是24位补码的按位取反掩码
                decimal_value = -(inverted_bits + 1)

            self.pressure_data = decimal_value  / 4096            
    
