'''
 * Filename    : pixel
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
#导入Pin, neopiexl和time模块
from machine import Pin
import neopixel
import time

#定义连接的引脚
led = Pin(14, Pin.OUT)
#定义led的数量
pixels = neopixel.NeoPixel(led, 4) 
#亮度:0 - 255
brightness=5

colors=[[brightness,0,0],                    #红
        [0,brightness,0],                    #绿
        [0,0,brightness],                    #蓝
        [brightness,brightness,brightness],  #白
        [0,0,0]]                             #关闭

#嵌套两个for循环，使模块反复显示红、绿、蓝、白、OFF五种状态    
while True:
    for i in range(0,5):
        for j in range(0,4):
            pixels[j] = colors[i]  #设置像素的颜色
            pixels.write()         #将数据写入像素
            time.sleep_ms(50)
        time.sleep_ms(500)
    time.sleep_ms(500)