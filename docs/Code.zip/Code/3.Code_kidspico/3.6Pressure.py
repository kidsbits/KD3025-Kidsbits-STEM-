'''
 * Filename    : Pressure
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import ADC  # 导入ADC模块
import time

# 开启并配置ADC，量程为0-3.3V
# io26,io27,io28,io29分别定义为ADC通道0,1,2,3
Pressure = ADC(28)  #也可以写成：Photores = ADC(2)

# 每0.1秒读取一次模拟值，将模拟值转换为电压输出
while True:
    Pressure_value = Pressure.read_u16()
    voltage = Pressure_value / 65535 * 3.3
    print('ADC Value:',Pressure_value,'   Voltage:',voltage,'V')
    time.sleep(0.1)